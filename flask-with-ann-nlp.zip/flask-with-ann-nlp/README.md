# Flask + ANN-NLP model
Run the following command:
```

cd flask-with-ann-nlp
pip install -r requirements.txt
set FLASK_ENV=development
python app.py
Go to browse http://127.0.0.1:5000/
```